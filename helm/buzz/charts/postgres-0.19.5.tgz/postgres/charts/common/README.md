# common

![Version: 2.2.0](https://img.shields.io/badge/Version-2.2.0-informational?style=flat-square) ![Type: library](https://img.shields.io/badge/Type-library-informational?style=flat-square) ![AppVersion: 2.2.0](https://img.shields.io/badge/AppVersion-2.2.0-informational?style=flat-square)

A library chart for common templates and helper functions

**Homepage:** <https://www.cloudpirates.io>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| CloudPirates GmbH & Co. KG | <hello@cloudpirates.io> | <https://www.cloudpirates.io> |

## Source Code

* <https://github.com/CloudPirates-io/helm-charts/tree/main/charts/common>

